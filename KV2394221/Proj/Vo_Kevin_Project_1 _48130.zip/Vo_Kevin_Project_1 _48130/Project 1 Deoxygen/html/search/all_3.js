var searchData=
[
  ['endbattle',['endBattle',['../main_8cpp.html#a320784b17438a6493d4a6823068cf6b3',1,'main.cpp']]]
];
