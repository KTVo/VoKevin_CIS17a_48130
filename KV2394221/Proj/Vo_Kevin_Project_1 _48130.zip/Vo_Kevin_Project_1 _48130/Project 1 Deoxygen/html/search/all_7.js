var searchData=
[
  ['username',['userName',['../struct_play.html#a4d9060044c087e729eaf90363683a136',1,'Play']]]
];
