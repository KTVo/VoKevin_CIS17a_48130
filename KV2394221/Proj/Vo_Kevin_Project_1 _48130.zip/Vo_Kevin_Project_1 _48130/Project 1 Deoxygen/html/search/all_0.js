var searchData=
[
  ['boss',['boss',['../main_8cpp.html#adcd0574cfe30b2535e1cae2840ba0e22',1,'main.cpp']]]
];
