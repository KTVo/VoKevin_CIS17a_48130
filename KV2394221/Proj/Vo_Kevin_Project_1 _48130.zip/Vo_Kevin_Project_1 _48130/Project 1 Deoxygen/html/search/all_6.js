var searchData=
[
  ['play',['Play',['../struct_play.html',1,'']]],
  ['playerdamage',['playerDamage',['../struct_play.html#ac937f89a2cff0d973be6a7996d327d69',1,'Play']]],
  ['playerhealth',['playerHealth',['../struct_play.html#acd4b4302358063ac72cb35f970096a5a',1,'Play']]]
];
